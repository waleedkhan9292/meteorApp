//
//  ItemCell.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on padding/07/padding21.
//

import UIKit

final class ItemCell: BaseTVCell {
    
    let lblName = UILabel()
    let lblInstruction = UILabel()
    
    private let ivArrow = UIImageView()
    
    private let uvSeparator = UIView()
    
    private let padding: CGFloat = 10
    
    override func setupView() {
        backgroundColor = .backgroundColor
        setupNameLabel()
        setupInstructionLabel()
        setupImage()
        setupSeparator()
    }
    
    override func configureCell(item: BaseTVCell.I) {
        if let item = item as? Meteor {
            lblName.text = item.name
            lblInstruction.text = "\(item.getFormatedDate ?? "") • \(item.getConvertedMass ?? 0.0) kg"
        }
    }

}

extension ItemCell {
    
    private func setupNameLabel() {
        
        addSubview(lblName)
        
        lblName.translatesAutoresizingMaskIntoConstraints = false
        
        lblName.textColor = .textColor
        
        NSLayoutConstraint.activate([
            lblName.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: padding),
            lblName.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: padding),
            lblName.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding)
        ])
    }
    
    private func setupInstructionLabel() {
        
        addSubview(lblInstruction)
        
        lblInstruction.translatesAutoresizingMaskIntoConstraints = false
        
        lblInstruction.numberOfLines = 2
        
        lblInstruction.textColor = .textColor
        
        NSLayoutConstraint.activate([
            lblInstruction.topAnchor.constraint(equalTo: lblName.bottomAnchor, constant: padding),
            lblInstruction.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: padding),
            lblInstruction.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding)
        ])
    }
    
    private func setupImage() {
        
        addSubview(ivArrow)
        
        ivArrow.translatesAutoresizingMaskIntoConstraints = false
        
        ivArrow.image = UIImage(systemName: "chevron.compact.right")?.withTintColor(.black)
        
        NSLayoutConstraint.activate([
            ivArrow.centerYAnchor.constraint(equalTo: safeAreaLayoutGuide.centerYAnchor),
            ivArrow.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding),
            ivArrow.heightAnchor.constraint(equalToConstant: 15),
            ivArrow.widthAnchor.constraint(equalToConstant: 15)
        ])
    }
    
    private func setupSeparator() {
        
        addSubview(uvSeparator)
        
        uvSeparator.translatesAutoresizingMaskIntoConstraints = false
        
        uvSeparator.backgroundColor = .textColor.withAlphaComponent(0.3)
        
        NSLayoutConstraint.activate([
            uvSeparator.topAnchor.constraint(equalTo: lblInstruction.bottomAnchor, constant: padding),
            uvSeparator.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
            uvSeparator.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding),
            uvSeparator.heightAnchor.constraint(equalToConstant: 1.0),
            uvSeparator.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor)
        ])
    }
}
