//
//  ItemListInteractor.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Combine
import Alamofire

final class ItemListInteractor: BaseInteractor, UserDefaultProtocol {
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var apiClient: ApiClientProtocol
    
    private var backupList: [Meteor] = []
    
    //MARK:- PUBLIC OBSERVERS
    
    @Published var sortType: sortType = .date
    @Published var dataSource: GenericTVDataSource<Meteor, ItemCell>? = GenericTVDataSource()
    
    //MARK:- CONSTRUCTOR
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
        super.init()
        setObserver()
    }
}

extension ItemListInteractor {
    
    //MARK:- PUBLIC METHODS
    func loadData() {
        loadDataFromLocalDB()
        loadListFromApi()
    }
    
    func setSortListType(type: sortType) {
        sortType = type
        filter(backupList)
    }
    
    //MARK:- PRIVATE METHODS
    private func loadListFromApi() {
        isShowingLoader = true
        let request: APIRouter = .getMeteorList
        apiClient.performRequest(route: request) { [unowned self] (response: AFDataResponse<[Meteor]>) in
            self.isShowingLoader = false
            switch response.result {
            case let .success(meteorList):
                saveInLocalDB(meteorList)
            case let .failure(error):
                self.error = error.errorDescription
            }
        }
    }
    
    private func filter(_ meteorList: [Meteor]) {
        
        dataSource?.data = meteorList
            .filter { dateComparison(of: $0.year) }
            .sorted { sortList(with: $0, and: $1) }
    }
    
    private func dateComparison(of meteorStrDate: String?) -> Bool {
        
        let secondStrDate = "1900-01-01T00:00:00.000"
        
        if let meteroDate = meteorStrDate?.strToDate,
           let secondDate = secondStrDate.strToDate {
            
            let components = Calendar.current.dateComponents([.year], from: meteroDate, to: secondDate)
            
            if let year = components.year,
               year <= 0 {
                return true
            }
        }
        
        return false
        
    }
    
    private func sortList(with firstMeteor: Meteor,
                          and secondMeteor: Meteor) -> Bool {
        switch sortType {
        case .date:
            return sortbyDate(with: firstMeteor, and: secondMeteor)
        case .size:
            return sortbySize(with: firstMeteor, and: secondMeteor)
        }
    }
    
    private func sortbyDate(with firstMeteor: Meteor,
                            and secondMeteor: Meteor) -> Bool {
        
        guard let firstMeteorDate = firstMeteor.year?.strToDate,
              let secondMeteorDate = secondMeteor.year?.strToDate,
              firstMeteorDate > secondMeteorDate else { return false }
        
        return true
    }
    
    private func sortbySize(with firstMeteor: Meteor,
                            and secondMeteor: Meteor) -> Bool {
        
        guard let firstMeteorSize = firstMeteor.getConvertedMass,
           let secondMeteorSize = secondMeteor.getConvertedMass,
           secondMeteorSize.isLess(than: firstMeteorSize) else { return false }
        
        return true
    }
    
    private func loadDataFromLocalDB() {
        if let loadedData: [Meteor] = loadData(key: .meteor) {
            backupList = loadedData
            filter(backupList)
        }
    }
    
    private func saveInLocalDB(_ meteorList: [Meteor]) {
        var tempList: [Meteor] = []
        meteorList.forEach { meteor in
            if let index = backupList.firstIndex(where: {meteor == $0 && ($0.isFavourite ?? false)}) {
                tempList.append(backupList[index])
            } else {
                tempList.append(meteor)
            }
        }
        backupList = tempList
        saveData(backupList, of: .meteor)
        filter(backupList)
    }
    
    private func setObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(notifyNotification(_:)), name: Notification.Name(NotificationConstants.updateFavourite.rawValue), object: nil)
    }
    
    @objc private func notifyNotification(_ nofication: Notification) {
        if let meteor = nofication.object as? Meteor {
            
            if let index = backupList.firstIndex(where: { $0 == meteor }) {
                backupList[index].isFavourite = meteor.isFavourite
                saveData(backupList, of: .meteor)
            }
            loadDataFromLocalDB()
        }
    }
    
    
}

