//
//  ItemDetailInteractor.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Combine
import Foundation

final class ItemDetailInteractor: BaseInteractor {
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    
    //MARK:- PUBLIC OBSERVERS
    @Published var meteor: Meteor?
    
    //MARK:- CONSTRUCTOR
    init(_ meteor: Meteor) {
        self.meteor = meteor
    }
}

extension ItemDetailInteractor {
    func addFavourite() {
        meteor?.isFavourite = true
        updateData() 
    }
    
    func removeFavourite() {
        meteor?.isFavourite = false
        updateData()
    }
    
    private func updateData() {
        NotificationCenter.default.post(name: Notification.Name(NotificationConstants.updateFavourite.rawValue), object: meteor)
    }
}
