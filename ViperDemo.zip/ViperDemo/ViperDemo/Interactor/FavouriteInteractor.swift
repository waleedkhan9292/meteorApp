//
//  FavouriteInteractor.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 20/09/2021.
//

import Combine
import Alamofire

final class FavouriteInteractor: BaseInteractor, UserDefaultProtocol {
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var apiClient: ApiClientProtocol
    private var backupList: [Meteor] = []
    
    //MARK:- PUBLIC OBSERVERS
    @Published var dataSource: GenericTVDataSource<Meteor, ItemCell>? = GenericTVDataSource()
    
    //MARK:- CONSTRUCTOR
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
        super.init()
        setObserver()
    }
}

extension FavouriteInteractor {
    
    //MARK:- PUBLIC METHODS
    func loadData() {
        loadDataFromLocalDB()
    }
    
    func updateDB() {
        saveData(backupList, of: .meteor)
        loadDataFromLocalDB()
    }
    
    //MARK:- PRIVATE METHODS
    private func loadDataFromLocalDB() {
        if let loadedData: [Meteor] = loadData(key: .meteor) {
            backupList = loadedData
            dataSource?.data = backupList.filter { $0.isFavourite ?? false }
        }
    }
    
    private func setObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(notifyNotification(_:)), name: Notification.Name(NotificationConstants.updateFavourite.rawValue), object: nil)
    }

    @objc private func notifyNotification(_ nofication: Notification) {
        if let meteor = nofication.object as? Meteor {
            
            if let index = backupList.firstIndex(where: { $0 == meteor}) {
                backupList[index].isFavourite = meteor.isFavourite
                saveData(backupList, of: .meteor)
            }
            loadDataFromLocalDB()
        }
    }
    
}
