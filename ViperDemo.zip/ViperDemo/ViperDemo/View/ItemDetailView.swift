//
//  ItemDetailView.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit
import MapKit

final class ItemDetailView: BaseView {
    
    let uvMapView = MKMapView()
    
    override func setupView() {
        setupMapView()
    }
}

extension ItemDetailView {
    
    func setupMapView() {
        addSubview(uvMapView)
        
        uvMapView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            uvMapView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor),
            uvMapView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
            uvMapView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor),
            uvMapView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor)
        ])
    }
}

