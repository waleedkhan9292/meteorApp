//
//  FavouriteListView.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 20/09/2021.
//

import UIKit

final class FavouriteListView: BaseView {
    
    let uitvItemList = UITableView()
    
    private let padding: CGFloat = 10
    
    override func setupView() {
        setupTableView()
    }
}

extension FavouriteListView {
    
    private func setupTableView() {
        
        addSubview(uitvItemList)
        
        uitvItemList.backgroundColor = .clear
        
        uitvItemList.separatorStyle = .none
        
        uitvItemList.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            uitvItemList.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: padding),
            uitvItemList.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding),
            uitvItemList.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: padding),
            uitvItemList.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -padding)
        ])
    }
}

