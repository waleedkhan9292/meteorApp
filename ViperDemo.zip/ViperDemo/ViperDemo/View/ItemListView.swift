//
//  ItemListView.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListView: BaseView {
    
    weak var controller: ItemListVC? {
        didSet {
            segmentControl.addTarget(controller, action:  #selector(controller?.btnOnTapSortType(_:)), for: .valueChanged)
        }
    }
    
    let uitvItemList = UITableView()
    
    let segmentControl : UISegmentedControl =  {
        let segmentControl = UISegmentedControl(items: [sortType.date.rawValue, sortType.size.rawValue])
        
        segmentControl.selectedSegmentIndex = 0
        segmentControl.selectedSegmentTintColor = .backgroundColor
        
        return segmentControl
    }()
    
    private let padding: CGFloat = 10
    
    override func setupView() {
        setupSegmentControl()
        setupTableView() 
    }
}

extension ItemListView {
    
    private func setupSegmentControl() {
        addSubview(segmentControl)
        
        segmentControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.textColor], for: .normal)
        segmentControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.textColor], for: .selected)
        
        segmentControl.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            segmentControl.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: padding),
            segmentControl.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding),
            segmentControl.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: padding)
        ])
    }
    private func setupTableView() {
        
        addSubview(uitvItemList)
        
        uitvItemList.backgroundColor = .clear
        
        uitvItemList.separatorStyle = .none
        
        uitvItemList.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            uitvItemList.topAnchor.constraint(equalTo: segmentControl.bottomAnchor, constant: padding),
            uitvItemList.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -padding),
            uitvItemList.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: padding),
            uitvItemList.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -padding)
        ])
    }
}

