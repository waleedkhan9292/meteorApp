//
//  ExtensionString.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 19/09/2021.
//

import Foundation

extension String {
    var strToDate: Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        return dateFormatter.date(from:self)
    }
}
