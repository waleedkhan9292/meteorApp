//
//  ExtensionDate.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 19/09/2021.
//

import Foundation

extension Date {
    var formatedStrDate: String {
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "MMM dd, yyyy"
        return dateFormatterPrint.string(from: self)
    }
}
