//
//  Drink.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Foundation

class Drink: Codable {
    
    var id: String
    var name: String
    var instructions: String

    enum CodingKeys: String, CodingKey {
        case id = "idDrink"
        case name = "strDrink"
        case instructions = "strInstructions"
    }

}
