//
//  Meteor.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 19/09/2021.
//

import Foundation

class Meteor: Codable {
    let name, id: String
    let nametype: String
    let recclass: String
    let mass: String?
    let fall: String
    let year, reclat, reclong: String?
    let geolocation: Geolocation?
    let computedRegionCbhkFwbd, computedRegionNnqa25F4: String?
    var isFavourite: Bool? = false

}

extension Meteor {
    enum CodingKeys: String, CodingKey {
        case name, id, nametype, recclass, mass, fall, year, reclat, reclong, geolocation, isFavourite
        case computedRegionCbhkFwbd = ":@computed_region_cbhk_fwbd"
        case computedRegionNnqa25F4 = ":@computed_region_nnqa_25f4"
    }
    
    var getConvertedMass: Double? {
       (Double(mass ?? "0.0") ?? 0.0) / 1000
    }
    
    var getFormatedDate: String? {
        guard let date = year?.strToDate else {
            return nil
        }
        return date.formatedStrDate
    }

}


extension Meteor: Equatable {
    static func == (lhs: Meteor, rhs: Meteor) -> Bool {
        lhs.id == rhs.id 
    }
}

