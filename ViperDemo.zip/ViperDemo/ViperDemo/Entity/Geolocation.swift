//
//  Geolocation.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 19/09/2021.
//

import Foundation

class Geolocation: Codable {
    let latitude, longitude: String
}
