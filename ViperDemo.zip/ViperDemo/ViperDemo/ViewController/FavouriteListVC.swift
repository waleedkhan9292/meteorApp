//
//  FavouriteListVC.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 20/09/2021.
//

import UIKit

final class FavouriteListVC: BaseVC<FavouriteListView, FavouritePresenter> {
    
    private var dataSource: GenericTVDataSource<Meteor, ItemCell>?
    
    var delegate: ItemDetailDelegate?
    
    override func configureViewOnLoad() {
        super.configureViewOnLoad()
        
        presenter.loadData()
        setNavigationTitle(with: "Favourites")
    }
    
    override func setupListener() {
        super.setupListener()
        
        presenter.$dataSource.sink { [unowned self] in
            if let dataSource = $0 {
                self.dataSource = dataSource
                configureTableView()
            }
        }
        .store(in: &cancellables)
        
        presenter.dataSource?.$data.sink { [unowned self] in
            _ = $0
            DispatchQueue.main.async {
                self.contentView.uitvItemList.reloadData()
            }
        }
        .store(in: &cancellables)
        
        presenter.$error.sink { [unowned self] in
            if let error = $0 {
                self.showErrorAlertView(title: "Error", description: error)
            }
        }
        .store(in: &cancellables)
        
        presenter.$isShowingLoader.sink { [unowned self] in
            $0 ? self.showLoader() : self.hideLoader()
        }
        .store(in: &cancellables)
    }
}

extension FavouriteListVC {
    //MARK:- BUTTON
    
    func configureTableView() {
            contentView.uitvItemList.delegate = self
            contentView.uitvItemList.dataSource = dataSource
            contentView.uitvItemList.register(ItemCell.self, forCellReuseIdentifier: ItemCell.reuseIdentifier)
    }
}

extension FavouriteListVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter.navigate(to: .detail,
                           index: indexPath.row,
                           navigationController: navigationController)
    }
}



extension FavouriteListVC: ItemDetailDelegate {
    func updateDB() {
        presenter.updateDB()
    }
}


protocol ItemDetailDelegate {
    func updateDB()
}
