//
//  ItemListVC.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListVC: BaseVC<ItemListView, ItemListPresenter> {
    
    private var dataSource: GenericTVDataSource<Meteor, ItemCell>?
    
    
    lazy var refreshControl: UIRefreshControl = {
       let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshList(_:)), for: UIControl.Event.valueChanged)
        return refreshControl
    }()
    
    override func configureViewOnLoad() {
        contentView.controller = self
        presenter.loadData()
        setNavigationTitle(with: "Meteor")
        configureTableViewPullToRefresh()
    }
    
    override func setupListener() {
        presenter.$dataSource.sink { [unowned self] in
            if let dataSource = $0 {
                self.dataSource = dataSource
                configureTableView()
            }
        }
        .store(in: &cancellables)
        
        presenter.dataSource?.$data.sink { [unowned self] in
            _ = $0
            DispatchQueue.main.async {
                contentView.uitvItemList.reloadData()
            }
        }
        .store(in: &cancellables)
        
        presenter.$error.sink { [unowned self] in
            if let error = $0 {
                self.showErrorAlertView(title: "Error", description: error)
            }
        }
        .store(in: &cancellables)
        
        presenter.$isShowingLoader.sink { [unowned self] in
            $0 ? self.showLoader() : self.hideLoader()
            if !$0 {
                
                refreshControl.endRefreshing()
            }
        }
        .store(in: &cancellables)
    }
}

extension ItemListVC {
    //MARK:- BUTTON
    @objc func btnOnTapSortType(_ sender: UISegmentedControl) {
        presenter.setSortListType(of: sortType.getSortType(of: sender.selectedSegmentIndex))
    }
    
    @objc func refreshList(_ sender: AnyObject) {
        presenter.loadData()
    }
    
    private func configureTableView() {
            contentView.uitvItemList.delegate = self
            contentView.uitvItemList.dataSource = dataSource
            contentView.uitvItemList.register(ItemCell.self, forCellReuseIdentifier: ItemCell.reuseIdentifier)
    }
    
    private func configureTableViewPullToRefresh() {
        
        contentView.uitvItemList.addSubview(refreshControl)
        refreshControl.tintColor = .textColor
        contentView.uitvItemList.refreshControl = refreshControl

    }

}

extension ItemListVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter.navigate(to: .detail,
                           index: indexPath.row,
                           navigationController: navigationController)
    }
}
