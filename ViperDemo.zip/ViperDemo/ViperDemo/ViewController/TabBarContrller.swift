//
//  TabBarContrller.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 19/09/2021.
//

import UIKit

final class TabBarContrller: UITabBarController {
    
    private var meteorListVC: ItemListVC
    private var favouriteListVC: FavouriteListVC
    
    
    init(apiClient: ApiClientProtocol = ApiClient()) {
        meteorListVC = ItemListVC(presenter: ItemListPresenter(interactor: ItemListInteractor(apiClient: apiClient)))
        favouriteListVC = FavouriteListVC(presenter: FavouritePresenter(interactor: FavouriteInteractor(apiClient: apiClient)))
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.barTintColor = .clear
        meteorListVC.tabBarItem = getTabbarItem(with: "Meteor", and: "meteorIcon")
        favouriteListVC.tabBarItem = getTabbarItem(with: "Favourites", and: "heartEmptyIcon")
        viewControllers = [
            UINavigationController(rootViewController: meteorListVC),
            UINavigationController(rootViewController: favouriteListVC)
        ]
    }

}

extension TabBarContrller {
    func getTabbarItem(with title: String, and imageName: String) -> UITabBarItem {
        let item = UITabBarItem()
        item.title = title
        item.image = UIImage(named: imageName)?.withTintColor(.textColor)
        item.selectedImage = UIImage(named: imageName)?.withTintColor(.selectedTabbarColor)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.textColor], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.selectedTabbarColor], for: .selected)
        return item
    }
}
