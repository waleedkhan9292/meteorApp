//
//  ItemDetailVC.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit
import MapKit

final class ItemDetailVC: BaseVC<ItemDetailView, ItemDetailPresenter> {
    override func configureViewOnLoad() {
        super.configureViewOnLoad()
    }
    
    override func setupListener() {
        super.setupListener()
        presenter.$meteor.sink { [unowned self] in
            if let item = $0,
               let lat = Double(item.geolocation?.latitude ?? "0.0"),
               let lng = Double(item.geolocation?.longitude ?? "0.0") {
                
                setNavigationTitle(with: item.name)
                setupFavouriteIcon(item.isFavourite ?? false)
                contentView.uvMapView.addAnnotation(getAnnotation(lat: lat, lng: lng))
                contentView.uvMapView.setRegion(getRegion(lat: lat, lng: lng), animated: true)
            }
        }
        .store(in: &cancellables)
        
    }
}

extension ItemDetailVC {
    private func getRegion(lat: Double, lng: Double) -> MKCoordinateRegion {
        let center = CLLocationCoordinate2D(latitude: lat, longitude: lng)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001))
        return region
    }
    
    private func getAnnotation(lat: Double, lng: Double) -> MKAnnotation {
        let annotation: MKPointAnnotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2DMake(lat, lng)
        return annotation
    }
    
    private func setupFavouriteIcon(_ isFavourite: Bool) {
        let image = UIImage(named: isFavourite ? "heartFilledIcon" : "heartEmptyIcon")?
            .withTintColor(isFavourite ? .selectedTabbarColor : .textColor)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style:.plain, target: self, action: #selector(btnOnTapFavourite(_:)))
    }
    
    @objc private func btnOnTapFavourite(_ sender: UIBarButtonItem) {
        if sender.image == UIImage(named: "heartFilledIcon")?.withTintColor(.selectedTabbarColor) {
            presenter.removeFavourite()
            sender.image = UIImage(named: "heartEmptyIcon")?.withTintColor(.textColor)
        } else {
            presenter.addFavourite()
            sender.image = UIImage(named: "heartFilledIcon")?.withTintColor(.selectedTabbarColor)
        }
    }
}
