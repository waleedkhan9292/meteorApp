//
//  FavouriteRouter.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 20/09/2021.
//

import UIKit

final class FavouriteRouter: BaseRouter {
    override func navigate(to type: ContentType, with content: Any) -> UIViewController {
        var controller  = UIViewController()
        switch type {
        case .detail:
            controller = ItemDetailVC(presenter: ItemDetailPresenter(interactor: ItemDetailInteractor(content as! Meteor)))
            controller.hidesBottomBarWhenPushed = true
        }
        return controller
    }
}
