//
//  UserDefaultKeys.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 19/09/2021.
//

import Foundation

enum UserDefaultKeys: String {
    case meteor
}
