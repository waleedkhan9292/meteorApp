//
//  NotificationConstants.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 21/09/2021.
//

import Foundation
enum NotificationConstants: String {
    case updateFavourite = "updateFavourite"
}
