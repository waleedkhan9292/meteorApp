//
//  BaseVCConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

protocol BaseVCConfigurable {
    func configureViewOnLoad()
}

