//
//  BaseCellConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Foundation

protocol BaseCellConfigurable {
    associatedtype I
    
    func setupView()
    
    func configureCell(item: I)
    
}

extension BaseCellConfigurable {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}
