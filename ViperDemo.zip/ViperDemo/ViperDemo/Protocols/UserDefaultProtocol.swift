//
//  UserDefaultProtocol.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 20/09/2021.
//

import Foundation
protocol UserDefaultProtocol { }

extension UserDefaultProtocol {
    
    func saveData<T>(_ object: T,
                     of key: UserDefaultKeys) where T: Codable {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(object) {
            let defaults = UserDefaults.standard
            defaults.set(encoded, forKey: key.rawValue)
        }
    }
    
    func loadData<T>(key: UserDefaultKeys) -> T? where T: Codable {
        if let data = UserDefaults.standard.object(forKey: key.rawValue) as? Data {
            let decoder = JSONDecoder()
            if let loadedObject = try? decoder.decode(T.self, from: data) {
                return loadedObject
            }
        }
        return nil
    }
}
