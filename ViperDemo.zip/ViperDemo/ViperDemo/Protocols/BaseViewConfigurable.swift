//
//  BaseViewConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

protocol BaseViewConfigurable {
    func setupView()
}

protocol MainContentView {
    associatedtype T
    var contentView: T { get }
}
