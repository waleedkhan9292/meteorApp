//
//  FavouritePresenter.swift
//  ViperDemo
//
//  Created by Haseeb Waheed Khan on 20/09/2021.
//

import UIKit

final class FavouritePresenter: BasePresenter<FavouriteInteractor> {
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var router = FavouriteRouter()
    
    //MARK:- PUBLIC OBSERVERS
    @Published var dataSource: GenericTVDataSource<Meteor, ItemCell>?
    
    override func setupListener() {
        super.setupListener()
        
        interactor.$dataSource
            .assign(to: \.dataSource, on: self)
            .store(in: &cancellables)
    }
}

extension FavouritePresenter {
    
    //MARK:- PUBLIC METHODS
    func loadData() {
        interactor.loadData()
    }
    
    func updateDB() {
        interactor.updateDB()
    }
    
    //MARK:- ROUTER METHODS
    func navigate(to type: ContentType, index: Int,
                  navigationController: UINavigationController?) {
        guard let item = dataSource?.data[index] else {
            print("No drink avaialble.")
            return
        }
        navigationController?.pushViewController(router.navigate(to: type, with: item), animated: true)
    }
    
    
    //MARK:- PRIVATE METHODS
}
