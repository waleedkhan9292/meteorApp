//
//  ItemListPresenter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListPresenter: BasePresenter<ItemListInteractor> {
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var router = ItemListRouter()
    
    //MARK:- PUBLIC OBSERVERS
    @Published var dataSource: GenericTVDataSource<Meteor, ItemCell>?
    
    override func setupListener() {
        interactor.$error
            .assign(to: \.error, on: self)
            .store(in: &cancellables)
        
        interactor.$isShowingLoader
            .assign(to: \.isShowingLoader, on: self)
            .store(in: &cancellables)
        
        interactor.$dataSource
            .assign(to: \.dataSource, on: self)
            .store(in: &cancellables)
    }
}

extension ItemListPresenter {
    
    //MARK:- PUBLIC METHODS
    func loadData() {
        interactor.loadData()
    }
    
    func setSortListType(of type: sortType) {
        interactor.setSortListType(type: type)
    }
    
    //MARK:- ROUTER METHODS
    func navigate(to type: ContentType, index: Int,
                  navigationController: UINavigationController?) {
        guard let item = interactor.dataSource?.data[index] else {
            print("No data avaialble.")
            return
        }
        
        navigationController?.pushViewController(router.navigate(to: type, with: item), animated: true)
        
    }
    
    
    //MARK:- PRIVATE METHODS
}
