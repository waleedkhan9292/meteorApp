//
//  ItemDetailPresenter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Foundation

final class ItemDetailPresenter: BasePresenter<ItemDetailInteractor> {
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var router = ItemListRouter()
    
    //MARK:- PUBLIC OBSERVERS
    @Published var meteor: Meteor?
    
    override func setupListener() {
        interactor.$error
            .assign(to: \.error, on: self)
            .store(in: &cancellables)
        
        interactor.$isShowingLoader
            .assign(to: \.isShowingLoader, on: self)
            .store(in: &cancellables)
        
        interactor.$meteor
            .assign(to: \.meteor, on: self)
            .store(in: &cancellables)
    }
}

extension ItemDetailPresenter {
    func addFavourite() {
        interactor.addFavourite()
    }
    
    func removeFavourite() {
        interactor.removeFavourite()
    }
}
