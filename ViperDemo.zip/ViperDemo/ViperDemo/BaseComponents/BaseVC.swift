//
//  BaseVC.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//


import UIKit
import Combine

typealias BaseConfigurable = UIViewController & BaseListenerConfigurable & BaseVCConfigurable & MainContentView

class BaseVC<AnyView, Presenter>: BaseConfigurable  where AnyView: UIView, Presenter: AnyObject {
    
    typealias T = AnyView
    
    var contentView: AnyView = AnyView()
    
    var cancellables = Set<AnyCancellable>()
    
    var presenter: Presenter
    
    private let alert = UIAlertController(title: "Loading...", message: nil, preferredStyle: .alert)
    private let activityIndicator = UIActivityIndicatorView(style: .large)
    
    init(presenter: Presenter) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        super.loadView()
        view = contentView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureNavigationBar()
        setupLoader()
        setupListener()
        configureViewOnLoad()
    }
    
    func setupListener() { }
    
    func configureViewOnLoad() { }
}

extension BaseVC {
    
    
    //MARK:- PUBLIC METHODS
    func showErrorAlertView(title:String, description:String) {
        let alert = UIAlertController(title: title,
                                      message: description,
                                      preferredStyle: .alert)
        let defaultButton = UIAlertAction(title: "OK",
                                          style: .default) { _ in }
        
        alert.addAction(defaultButton)
        present(alert, animated: true)
    }
    
    func showLoader() {
        activityIndicator.startAnimating()
        present(alert, animated: true)
    }
    
    func hideLoader() {
        dismiss(animated: true)
        activityIndicator.stopAnimating()
    }
    
    func setNavigationTitle(with name: String) {
         navigationItem.title = name
    }
    
    //MARK:- PRIVATE METHODS
    private func configureNavigationBar() {
        
        setupNavTitleColor()
        setupNavBackButtonImage()
        
        navigationController?.navigationBar.barTintColor = .clear
        navigationController?.navigationBar.prefersLargeTitles = false
    }
    
    private func setupNavTitleColor() {
        let textAttributes = [NSAttributedString.Key.foregroundColor: UIColor.textColor]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
    }
    
    private func setupNavBackButtonImage() {
        let backImage = UIImage(named: "back")?.withTintColor(.textColor)
        navigationController?.navigationBar.backIndicatorImage = backImage
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = backImage
        navigationItem.backButtonDisplayMode = .minimal
    }
    
    private func setupLoader() {
        
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.isUserInteractionEnabled = false

        alert.view.addSubview(activityIndicator)
        alert.view.heightAnchor.constraint(equalToConstant: 95).isActive = true

        activityIndicator.centerXAnchor.constraint(equalTo: alert.view.centerXAnchor, constant: 0).isActive = true
        activityIndicator.bottomAnchor.constraint(equalTo: alert.view.bottomAnchor, constant: -20).isActive = true
        
    }
    
}
